[Sunguk (Edmund) Ham], [A00979841], [E], [April 4th, 2017]

This assignment is [100]% complete.


------------------------
Question one (PalindromeTester) status:

[complete]

------------------------
Question two (RockPaperScissors) status:

[complete]

------------------------
Question three (TestStudent and Student) status:

[complete]

------------------------
Question four (Primes and supporting classes) status:

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
