package q3;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.Timer;
import javax.swing.JPanel;

public class StopWatchPanel extends JPanel{
    
    private int second;
    private int minute;
    private final int pivotX = 200;
    private final int pivotY = 200;
    private int moveX;
    private int moveY;
    private final int maxDistanceSquare = 40000;
    JButton start = new JButton("Start");
    JButton reset = new JButton("Reset");
    JButton stop = new JButton("Stop");
    JLabel time = new JLabel(minute + " : " + second);
    Timer minuteTimer = new Timer(1000, new StopWatchListener());
    Timer secondTimer = new Timer(60000, new StopWatchListener());

    public StopWatchPanel() {
        setBackground(Color.white);
        setPreferredSize(new Dimension(400, 500));
        
        
        minuteTimer.start();
        secondTimer.start();
        add(Box.createRigidArea(new Dimension(400, 400)));
        add(time);
        add(Box.createRigidArea(new Dimension(400, 20)));
        add(start);
        add(reset);
        add(stop);
    }
    
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        g.setColor(Color.black);
        g.fillOval(0, 0, 400, 400);
        
        g.setColor(Color.white);
        g.fillOval(195, 195, 10, 10);
        
//        g.drawLine(pivotY, pivotY, moveX, moveY);
    }
    
    private class StopWatchListener implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            second++;
            minute++;
            repaint();
//            if (event.getSource() == start) {
//            }
//            if (event.getSource() == reset) {
//                minuteTimer.stop();
//                secondTimer.stop();
//                minute = 0;
//                second = 0;
//            }
//            if (event.getSource() == stop) {
//                minuteTimer.stop();
//                secondTimer.stop();
//            }
        }
    }
    
}
