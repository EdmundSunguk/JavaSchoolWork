[Student Name], [Student ID], [Set], [Date]

This assignment is [enter percent]% complete.


------------------------
Question one (Statistics) status:

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question two (DrawRectangle) status:

[complete or not complete]
[explanation if not complete, what is working/not working]

------------------------
Question three (StopWatch) status:

[complete or not complete]
[explanation if not complete, what is working/not working]
